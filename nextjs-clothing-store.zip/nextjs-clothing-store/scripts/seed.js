/**
 * Run with: MONGODB_URI set in env or in .env and `node scripts/seed.js`
 * This script inserts sample products into `clothing-store.products` collection.
 */
const { MongoClient } = require('mongodb')
require('dotenv').config()

async function main() {
  const uri = process.env.MONGODB_URI
  if (!uri) {
    console.error('MONGODB_URI not set. Aborting.')
    process.exit(1)
  }
  const client = new MongoClient(uri)
  try {
    await client.connect()
    const db = client.db('clothing-store')
    const products = [
      { title: 'تی‌شرت سفید', price: 299000, image: '/images/tshirt-white.jpg', category: 'زنانه', sizes: ['S','M','L'] },
      { title: 'شلوار جین', price: 599000, image: '/images/jeans.jpg', category: 'مردانه', sizes: ['M','L','XL'] },
      { title: 'کاپشن زمستانی', price: 1299000, image: '/images/jacket.jpg', category: 'زنانه', sizes: ['M','L','XL'] },
    ]
    await db.collection('products').deleteMany({})
    const r = await db.collection('products').insertMany(products)
    console.log('Inserted', r.insertedCount, 'products.')
  } catch (e) {
    console.error(e)
  } finally {
    await client.close()
  }
}

main()
