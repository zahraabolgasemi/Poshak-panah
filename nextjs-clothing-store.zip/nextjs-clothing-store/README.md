# فروشگاه پوشاک — Next.js + Tailwind (نسخه آماده)

این پروژه شامل کد فرانت‌اند و API ساده برای فروشگاه پوشاک است. در این بسته:
- Next.js (TypeScript) + TailwindCSS
- APIهای ساده در `pages/api` برای محصولات، auth و سفارشات
- اسکریپت `scripts/seed.js` برای وارد کردن داده‌های نمونه به MongoDB (نیاز به MONGODB_URI)
- نمونهٔ اتصال به زرین‌پال با استفاده از بسته `zarinpal-checkout` (نیاز به کلید درگاه)

## راه‌اندازی محلی
1. `npm install`
2. یک فایل `.env` مطابق `.env.example` بساز و متغیرها را قرار بده.
3. `npm run seed` برای اضافه کردن دادهٔ نمونه (اگر `MONGODB_URI` تنظیم شده باشد)
4. `npm run dev` و مرور `http://localhost:3000`

## متغیرهای محیطی (.env)
```
NEXT_PUBLIC_SITE_NAME="فروشگاه پوشاک من"
MONGODB_URI="your_mongodb_connection_string"
JWT_SECRET="very_secret_key"
ZARINPAL_MERCHANT_ID="your_zarinpal_merchant_id"
```
