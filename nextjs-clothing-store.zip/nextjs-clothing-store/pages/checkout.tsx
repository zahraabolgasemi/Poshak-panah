import axios from 'axios'

export default function Checkout() {
  const handlePay = async () => {
    const items = [{ id: 'p1', qty: 1 }]
    const totalAmount = 50000
    const r = await axios.post('/api/orders', { items, totalAmount })
    if (r.data.paymentUrl) {
      window.location.href = r.data.paymentUrl
    } else {
      alert('خطا در ایجاد پرداخت')
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-4">تسویه‌حساب</h1>
      <div className="bg-white p-4 rounded-2xl shadow-sm">
        <button onClick={handlePay} className="w-full py-3 rounded-lg bg-green-600 text-white">پرداخت</button>
      </div>
    </div>
  )
}
