export default function Cart() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-4">سبد خرید</h1>
      <div className="bg-white p-4 rounded-2xl shadow-sm">
        <p>این صفحه نمونه است. آیتم‌ها از localStorage یا context خوانده می‌شوند.</p>
      </div>
    </div>
  )
}
