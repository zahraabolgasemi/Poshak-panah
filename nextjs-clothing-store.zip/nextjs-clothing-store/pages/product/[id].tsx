import { useRouter } from 'next/router'
import useSWR from 'swr'
import axios from 'axios'

const fetcher = (url: string) => axios.get(url).then(r => r.data)

export default function ProductPage() {
  const router = useRouter()
  const { id } = router.query
  const { data: product } = useSWR(id ? `/api/products?id=${id}` : null, fetcher)

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="bg-white rounded-2xl p-4 shadow-sm">
        <div className="aspect-[3/2] mb-4 overflow-hidden rounded-lg">
          <img src={product?.image} className="w-full h-full object-cover" />
        </div>
        <h2 className="text-xl font-bold">{product?.title}</h2>
        <p className="text-gray-600 mt-2">{product?.price} تومان</p>
        <p className="mt-4">توضیحات محصول ...</p>
        <div className="mt-4 flex gap-2">
          <button className="px-4 py-2 rounded-lg bg-blue-600 text-white">افزودن به سبد</button>
          <button className="px-4 py-2 rounded-lg border">خرید سریع</button>
        </div>
      </div>
    </div>
  )
}
