import useSWR from 'swr'
import axios from 'axios'
import Link from 'next/link'

const fetcher = (url: string) => axios.get(url).then(r => r.data)

export default function Home() {
  const { data: products } = useSWR('/api/products', fetcher)

  return (
    <div className="min-h-screen">
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/"> <a className="font-bold text-xl">فروشگاه پوشاک</a> </Link>
          <nav className="flex items-center gap-4">
            <Link href="/">خانه</Link>
            <Link href="/cart">سبد خرید</Link>
          </nav>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-4">محصولات</h1>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {products?.map((p: any) => (
            <div key={p._id || p.id} className="bg-white rounded-2xl p-4 shadow-sm">
              <div className="aspect-square rounded-lg overflow-hidden mb-3">
                <img src={p.image} alt={p.title} className="object-cover w-full h-full" />
              </div>
              <h3 className="font-medium">{p.title}</h3>
              <p className="text-sm text-gray-500">{p.category}</p>
              <div className="flex items-center justify-between mt-3">
                <span className="font-semibold">{p.price} تومان</span>
                <Link href={`/product/${p._id || p.id}`}><a className="text-sm">مشاهده</a></Link>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
