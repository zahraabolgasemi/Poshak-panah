import type { NextApiRequest, NextApiResponse } from 'next'
import clientPromise from '../../lib/mongodb'

const mockProducts = [
  { id: 'p1', title: 'تی‌شرت سفید', price: 299000, image: '/images/tshirt-white.jpg', category: 'زنانه', sizes: ['S','M','L'] },
  { id: 'p2', title: 'شلوار جین', price: 599000, image: '/images/jeans.jpg', category: 'مردانه', sizes: ['M','L','XL'] },
]

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const client = await clientPromise
    const db = client.db('clothing-store')
    const products = await db.collection('products').find().limit(100).toArray()
    if (products.length) return res.status(200).json(products)
  } catch (e) {
    // fall back to mock
  }
  res.status(200).json(mockProducts)
}
