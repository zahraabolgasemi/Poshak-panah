import type { NextApiRequest, NextApiResponse } from 'next'
import clientPromise from '../../lib/mongodb'
import ZarinpalCheckout from 'zarinpal-checkout'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    const { items, totalAmount } = req.body
    // Save order to DB (simplified)
    try {
      const client = await clientPromise
      const db = client.db('clothing-store')
      const order = { items, totalAmount, status: 'pending', createdAt: new Date() }
      const r = await db.collection('orders').insertOne(order)
      const orderId = r.insertedId.toString()

      // Create Zarinpal payment
      const merchant_id = process.env.ZARINPAL_MERCHANT_ID || ''
      const zarinpal = new ZarinpalCheckout(merchant_id, { sandbox: true })
      const response = await zarinpal.payments.create({ amount: totalAmount, callbackUrl: `${process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'}/api/orders/verify?orderId=${orderId}`, description: `پرداخت سفارش ${orderId}` })

      // response contains authority to build redirect url
      const authority = response.authority || response.data?.authority
      const redirectUrl = zarinpal.payments.getRedirectUrl(authority)
      return res.status(201).json({ orderId, paymentUrl: redirectUrl })
    } catch (e: any) {
      console.error(e)
      return res.status(500).json({ message: e.message || 'error' })
    }
  }
  res.status(405).end()
}
