import type { NextApiRequest, NextApiResponse } from 'next'
import ZarinpalCheckout from 'zarinpal-checkout'
import clientPromise from '../../../lib/mongodb'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { Authority, Status, orderId } = req.query
  const merchant_id = process.env.ZARINPAL_MERCHANT_ID || ''
  const zarinpal = new ZarinpalCheckout(merchant_id, { sandbox: true })

  if (Status !== 'OK') return res.status(400).send('پرداخت موفق نبود')

  try {
    const verify = await zarinpal.payments.verify({ authority: String(Authority), amount: 0 }) // amount optional here depending on SDK
    // Update order status in DB
    const client = await clientPromise
    const db = client.db('clothing-store')
    await db.collection('orders').updateOne({ _id: require('mongodb').ObjectId(orderId) }, { $set: { status: 'paid', paidAt: new Date(), referenceId: verify.refId || verify.data?.refId } })
    res.redirect('/thank-you')
  } catch (e: any) {
    console.error(e)
    res.status(500).send('خطا در تایید پرداخت')
  }
}
